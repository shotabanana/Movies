class MoviesController < ApplicationController
end
