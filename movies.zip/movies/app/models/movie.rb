class Movie < ApplicationRecord
  belongs_to :user
  has_many :postcomments, dependent: :destroy
end
