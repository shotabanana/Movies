# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '63311da250e16b719ae2fd12409b9ce183a640a2e8aa1441cf1029e13c1616f480b8ceb8a025f683882ad7e68c636fccfc3e5fb2a02ac6605e63f89a8ac2adfa'