class MoviesController < ApplicationController

  def index
    @movie_new = Movie.new
    @user = User.find(current_user.id)
    @movies = Movie.all
    @movie = Movie.new
  end

  def show
    @movie = Movie.find(params[:id])
    @user = User.find(@movie.user_id)
    @movie_new = Movie.new
  end

  def edit
    @movie = Movie.find(params[:id])
    redirect_to movies_path unless current_user.id == @movie.user.id
  end

  def create
    @movie = Movie.new(movie_params)
    @movie.user_id = current_user.id
    if @movie.save
      flash[:notice] = 'You have created movie successfully.'
      redirect_to movie_path(@movie.id)
    else
      @user = User.find(current_user.id)
      @movies = Movie.all
      render :index
    end
  end

  def update
    @movie = Movie.find(params[:id])
    if @movie.update(movie_params)
      flash[:notice] = 'You have updated movie successfully.'
      redirect_to movie_path(@movie.id)
    else
      render :edit
    end
  end

  def destroy
    movie = Movie.find(params[:id])
    movie.destroy
    redirect_to movies_path
  end

  private
  def movie_params
    params.require(:movie).permit(:title, :body)
  end

end
