class PostCommentsController < ApplicationController
end
